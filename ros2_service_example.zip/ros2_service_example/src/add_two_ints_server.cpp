#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/srv/add_two_ints.hpp"

#include <memory>

using namespace std::chrono_literals;

class AddTwoIntsServer : public rclcpp::Node
{
public:
    AddTwoIntsServer() : Node("add_two_ints_server")
    {
        // 创建服务
        service_ = create_service<example_interfaces::srv::AddTwoInts>(
            "add_two_ints",
            std::bind(&AddTwoIntsServer::handle_add_two_ints, this,
                     std::placeholders::_1, std::placeholders::_2));
        
        RCLCPP_INFO(get_logger(), "AddTwoInts 服务已启动，等待请求...");
    }

private:
    rclcpp::Service<example_interfaces::srv::AddTwoInts>::SharedPtr service_;
    
    void handle_add_two_ints(
        const std::shared_ptr<example_interfaces::srv::AddTwoInts::Request> request,
        std::shared_ptr<example_interfaces::srv::AddTwoInts::Response> response)
    {
        // 处理请求
        RCLCPP_INFO(get_logger(), "收到请求: %ld + %ld", request->a, request->b);
        
        // 计算和
        response->sum = request->a + request->b;
        
    }
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    
    auto server = std::make_shared<AddTwoIntsServer>();
    
    RCLCPP_INFO(server->get_logger(), "AddTwoInts 服务节点启动");
    
    rclcpp::spin(server);
    rclcpp::shutdown();
    
    return 0;
}